const express = require('express');
const mongoose = require('mongoose');
const app = express();
const port=5725;
app.set('json spaces', 2);
app.use(express.json());
app.use(express.urlencoded({ extended: true}));
const User = new mongoose.model('User',{
    email: String,
    fullname: String,
    phone: String,
    password: String,
});
const Opinia = new mongoose.model('Opinia', {
    opinia: String,
    restauracja: String,
});
app.listen(port, () => {
    console.log(`Adres serwera: http://localhost:${port} \n`);
});

app.put('/login', async (req, res) => {
    try
    {
        await mongoose.connect('mongodb://localhost:27017/Aplikacja');
        const user = await User.findOne({email:req.body.email}).exec();
        if(user && user.password === req.body.password)
        {
            res.send({success:'Pomyślnie zalogowano'});
        }
        else
        {
            res.send({error:'Błędne dane'});
        }
    }
    catch(error)
    {
        res.send({'error':error});
    }
});

app.post('/register', async (req, res) => {
    try
    {
        await mongoose.connect('mongodb://localhost:27017/Aplikacja');
        const result = await User.findOne({email:req.body.email}).exec();
        if(result === null)
        {
            const user = new User(req.body);
            user.save();
            console.log("jestes tu wogule");
            res.send({success:'Zarejestrowano pomyślnie'});
        }
        else
        {
            res.send({error:'Podany email już istnieje'});
        }
    }
    catch(error)
    {
        console.log(error);
        res.send({'error':error});
    }
});

app.post('/opinie/dodaj', async (req, res) => {
    try {
        await mongoose.connect('mongodb://localhost:27017/Aplikacja');
        const opin = new Opinia(req.body);
        opin.save();
        res.send({ success: 'Opinia została dodana' });
    } catch (error) {
        console.log(error);
        res.send({ error: error.message });
    }
});

app.get('/opinie/:restauracja', async (req, res) => {
    try {
        await mongoose.connect('mongodb://localhost:27017/Aplikacja');
        const opinie = await Opinia.find({ restauracja: req.params.restauracja }, 'opinia');
        res.send({ success: 'Pobrano opinie', opinie: opinie.map(opinia => opinia.opinia) });
    } catch (error) {
        console.log(error);
        res.send({ error: error.message });
    }
});
